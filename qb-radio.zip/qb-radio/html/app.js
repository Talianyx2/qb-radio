const radioEl = document.getElementById('radio');
const statusEl = document.getElementById('status');
const freqEl = document.getElementById('frequency');
const volumeEl = document.getElementById('volume');
const freqInput = document.getElementById('freqInput');
const volMinus = document.getElementById('volMinus');
const volPlus = document.getElementById('volPlus');
const animBtn = document.getElementById('animBtn');
const offBtn = document.getElementById('offBtn');
const animMenu = document.getElementById('animMenu');
const animList = document.getElementById('animList');
const animClose = document.getElementById('animClose');
const clearBtn = document.getElementById('clearBtn');
const padTuneBtn = document.getElementById('padTuneBtn');
const keypadBtns = document.querySelectorAll('.kp-btn[data-num]');

let state = {
    channel: 0,
    volume: 50,
    minVolume: 0,
    maxVolume: 100,
    minChannel: 1,
    maxChannel: 999,
    animIndex: 1,
    anims: [],
};

function setStatus(on) {
    statusEl.textContent = on ? 'RADIO ON' : 'RADIO';
    statusEl.classList.toggle('on', on);
}

function updateDisplay() {
    if (state.channel > 0) {
        freqEl.textContent = state.channel;
        freqEl.style.visibility = 'visible';
    } else {
        freqEl.textContent = '--';
        freqEl.style.visibility = 'hidden';
    }
    volumeEl.textContent = 'VOL: ' + state.volume;
}

function setChannel(channel) {
    state.channel = channel;
    setStatus(channel > 0);
    updateDisplay();
}

function runFetch(action, data) {
    return fetch('https://qb-radio/' + action, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {}),
    }).catch(() => {});
}

function requestChannel(channel) {
    if (channel >= state.minChannel && channel <= state.maxChannel) {
        setChannel(channel);
        runFetch('connect', { channel });
        freqInput.value = '';
    }
}

function sanitizeInput(val) {
    const clean = val.replace(/[^0-9.]/g, '');
    const parts = clean.split('.');
    const int = parts[0].slice(0, 3);
    const dec = parts.length > 1 ? parts.slice(1).join('').slice(0, 2) : '';
    return parts.length > 1 ? int + '.' + dec : int;
}

window.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.action === 'open') {
        Object.assign(state, data);
        radioEl.classList.add('open');
        if (data.anims && data.anims.length) {
            buildAnimMenu(data.anims);
        }
        setChannel(data.channel || 0);
        volumeEl.textContent = 'VOL: ' + state.volume;
        freqInput.focus();
    } else if (data.action === 'close') {
        radioEl.classList.remove('open');
        animMenu.classList.add('hidden');
    } else if (data.action === 'updateChannel') {
        setChannel(data.channel || 0);
    }
});

function buildAnimMenu(anims) {
    animList.innerHTML = '';
    anims.forEach((anim, i) => {
        const item = document.createElement('div');
        item.className = 'anim-item';
        if (i + 1 === state.animIndex) item.classList.add('selected');
        const name = document.createElement('div');
        name.className = 'anim-name';
        name.textContent = anim.name;
        const desc = document.createElement('div');
        desc.textContent = 'Switch to ' + anim.name;
        item.appendChild(name);
        item.appendChild(desc);
        item.addEventListener('click', () => {
            state.animIndex = i + 1;
            document.querySelectorAll('.anim-item').forEach((el, j) => {
                el.classList.toggle('selected', j === i);
            });
            runFetch('setAnim', { index: state.animIndex });
        });
        animList.appendChild(item);
    });
}

freqInput.addEventListener('input', (e) => {
    e.target.value = sanitizeInput(e.target.value);
});

freqInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        const ch = parseFloat(freqInput.value);
        if (!isNaN(ch)) requestChannel(ch);
    }
});

volMinus.addEventListener('click', () => {
    state.volume = Math.max(state.minVolume, state.volume - 5);
    volumeEl.textContent = 'VOL: ' + state.volume;
    runFetch('setVolume', { volume: state.volume });
});

volPlus.addEventListener('click', () => {
    state.volume = Math.min(state.maxVolume, state.volume + 5);
    volumeEl.textContent = 'VOL: ' + state.volume;
    runFetch('setVolume', { volume: state.volume });
});

animBtn.addEventListener('click', () => {
    animMenu.classList.toggle('hidden');
});

animClose.addEventListener('click', () => {
    animMenu.classList.add('hidden');
});

offBtn.addEventListener('click', () => {
    setChannel(0);
    runFetch('off');
});

keypadBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
        const val = sanitizeInput(freqInput.value + btn.dataset.num);
        freqInput.value = val;
        freqInput.focus();
    });
});

clearBtn.addEventListener('click', () => {
    freqInput.value = '';
    freqInput.focus();
});

padTuneBtn.addEventListener('click', () => {
    const ch = parseFloat(freqInput.value);
    if (!isNaN(ch)) requestChannel(ch);
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        animMenu.classList.add('hidden');
        runFetch('close');
    }
});
