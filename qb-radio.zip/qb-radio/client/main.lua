local QBCore = exports['qb-core']:GetCoreObject()

local radioOn = false
local currentChannel = 0
local currentVolume = Config.DefaultVolume
local currentAnim = 1
local nuiOpen = false

local function IsDead()
    return LocalPlayer.state.isDead or IsPlayerDead(PlayerId())
end

local function SyncVolume()
    exports['pma-voice']:setRadioVolume(currentVolume)
end

local radioTransmitting = false

local function BlockShoot(active)
    radioTransmitting = active
    if not active then return end

    CreateThread(function()
        while radioTransmitting do
            local ped = PlayerPedId()
            DisablePlayerFiring(ped, true)
            DisableControlAction(0, 23, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 257, true)
            Wait(0)
        end
    end)
end

RegisterNetEvent('pma-voice:radioActive', function(active)
    BlockShoot(active)
end)

local function ApplyAnim()
    exports['pma-voice']:setRadioTalkAnim(
        Config.Animations[currentAnim].dict or 'random@arrests',
        Config.Animations[currentAnim].anim or 'generic_radio_enter'
    )
    if Config.Animations[currentAnim].dict then
        exports['pma-voice']:setDisableRadioAnim(false)
    else
        exports['pma-voice']:setDisableRadioAnim(true)
    end
end

local function OpenUI()
    if nuiOpen then return end
    nuiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        channel = currentChannel,
        volume = currentVolume,
        animIndex = currentAnim,
        anims = Config.Animations,
        minChannel = Config.MinChannel,
        maxChannel = Config.MaxChannel,
        minVolume = Config.MinVolume,
        maxVolume = Config.MaxVolume,
        primaryColor = Config.PrimaryColor,
    })
end

local function CloseUI()
    if not nuiOpen then return end
    nuiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

local function TurnRadioOff()
    if radioOn then
        TriggerServerEvent('qb-radio:server:off')
    end
    radioOn = false
    currentChannel = 0
    SendNUIMessage({ action = 'updateChannel', channel = 0 })
end

RegisterNetEvent('qb-radio:client:openDevice', function()
    if IsDead() then
        QBCore.Functions.Notify('Cannot use radio while dead.', 'error')
        return
    end
    ApplyAnim()
    OpenUI()
end)

RegisterNetEvent('qb-radio:client:rejected', function()
    radioOn = false
    currentChannel = 0
    SendNUIMessage({ action = 'updateChannel', channel = 0 })
end)

RegisterNUICallback('connect', function(data, cb)
    local channel = tonumber(data.channel)
    if channel and channel >= Config.MinChannel and channel <= Config.MaxChannel then
        radioOn = true
        currentChannel = channel
        TriggerServerEvent('qb-radio:server:setChannel', channel)
    end
    cb('ok')
end)

RegisterNUICallback('off', function(data, cb)
    TurnRadioOff()
    cb('ok')
end)

RegisterNUICallback('setVolume', function(data, cb)
    local vol = tonumber(data.volume)
    if not vol then cb('ok') return end
    vol = math.max(Config.MinVolume, math.min(Config.MaxVolume, vol))
    currentVolume = vol
    SyncVolume()
    cb('ok')
end)

RegisterNUICallback('setAnim', function(data, cb)
    local idx = tonumber(data.index)
    if idx and Config.Animations[idx] then
        currentAnim = idx
        ApplyAnim()
        QBCore.Functions.Notify('Animation set to: ' .. Config.Animations[idx].name, 'primary')
    end
    cb('ok')
end)

RegisterNUICallback('close', function(data, cb)
    CloseUI()
    cb('ok')
end)

RegisterCommand('radio', function()
    if IsDead() then
        QBCore.Functions.Notify('Cannot use radio while dead.', 'error')
        return
    end
    ApplyAnim()
    OpenUI()
end, false)

AddStateBagChangeHandler('isDead', ('player:%s'):format(GetPlayerServerId(PlayerId())), function(_, _, value)
    if value and (radioOn or nuiOpen) then
        TurnRadioOff()
        if nuiOpen then CloseUI() end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if nuiOpen then CloseUI() end
    if radioOn then TriggerServerEvent('qb-radio:server:off') end
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    radioOn = false
    currentChannel = 0
    currentVolume = Config.DefaultVolume
    ApplyAnim()
    SyncVolume()
end)