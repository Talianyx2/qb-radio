local QBCore = exports['qb-core']:GetCoreObject()

local lastChannelChange = {}
local CHANNEL_CHANGE_COOLDOWN = 2000

RegisterCommand('radio', function(source, args, rawCommand)
    TriggerClientEvent('qb-radio:client:openDevice', source)
end, false)

local function IsPlayerRadioReady(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    local item = Player.Functions.GetItemByName(Config.RadioItem)
    return item ~= nil
end

local function IsPolice(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    return Config.PoliceJobs[Player.PlayerData.job.name] == true
end

local function CanJoinChannel(source, channel)
    if channel == Config.PoliceChannel then
        return IsPolice(source)
    end
    return true
end

local function IsOnCooldown(source)
    local now = GetGameTimer()
    if lastChannelChange[source] and (now - lastChannelChange[source]) < CHANNEL_CHANGE_COOLDOWN then
        return true
    end
    lastChannelChange[source] = now
    return false
end

exports['pma-voice']:addChannelCheck(Config.PoliceChannel, function(source)
    return IsPolice(source)
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    exports['pma-voice']:addChannelCheck(Config.PoliceChannel, function(source)
        return IsPolice(source)
    end)
end)

AddEventHandler('playerDropped', function()
    local src = source
    lastChannelChange[src] = nil
end)

QBCore.Functions.CreateUseableItem(Config.RadioItem, function(source, item)
    local src = source
    if not IsPlayerRadioReady(src) then
        TriggerClientEvent('QBCore:Notify', src, 'You do not have a radio.', 'error')
        return
    end
    TriggerClientEvent('qb-radio:client:openDevice', src)
end)

RegisterNetEvent('qb-radio:server:setChannel', function(channel)
    local src = source
    channel = tonumber(channel)

    if not channel then
        TriggerClientEvent('QBCore:Notify', src, 'Invalid frequency.', 'error')
        return
    end

    if channel < Config.MinChannel or channel > Config.MaxChannel then
        TriggerClientEvent('QBCore:Notify', src, 'Frequency must be ' .. Config.MinChannel .. '-' .. Config.MaxChannel .. '.', 'error')
        return
    end

    if not IsPlayerRadioReady(src) then
        TriggerClientEvent('QBCore:Notify', src, 'You do not have a radio.', 'error')
        return
    end

    if not CanJoinChannel(src, channel) then
        TriggerClientEvent('QBCore:Notify', src, 'Access denied to channel ' .. channel .. '.', 'error')
        TriggerClientEvent('qb-radio:client:rejected', src)
        return
    end

    if IsOnCooldown(src) then
        TriggerClientEvent('QBCore:Notify', src, 'Please wait before changing frequency.', 'error')
        return
    end

    exports['pma-voice']:setPlayerRadio(src, channel)
    TriggerClientEvent('QBCore:Notify', src, 'Tuned to ' .. tostring(channel) .. ' MHz.', 'success')
    TriggerEvent('qb-radio:server:channelChanged', src, channel)
end)

RegisterNetEvent('qb-radio:server:off', function()
    local src = source
    if not IsPlayerRadioReady(src) then return end

    if IsOnCooldown(src) then return end

    exports['pma-voice']:setPlayerRadio(src, 0)
    TriggerClientEvent('QBCore:Notify', src, 'Radio turned off.', 'primary')
    TriggerEvent('qb-radio:server:channelChanged', src, 0)
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    exports['pma-voice']:removeChannelCheck(Config.PoliceChannel)
end)
