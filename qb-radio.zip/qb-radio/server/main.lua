local QBCore = exports['qb-core']:GetCoreObject()

local lastChannelChange = {}
local CHANNEL_CHANGE_COOLDOWN = 2000

local function IsPlayerDead(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return true end
    return Player.PlayerData.metadata['isdead'] == true
        or Player.PlayerData.metadata['inlaststand'] == true
end

RegisterCommand('radio', function(source, args, rawCommand)
    if IsPlayerDead(source) then
        TriggerClientEvent('QBCore:Notify', source, 'You cannot use a radio while dead.', 'error')
        return
    end
    TriggerClientEvent('qb-radio:client:openDevice', source)
end, false)

local function IsPlayerRadioReady(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    local item = Player.Functions.GetItemByName(Config.RadioItem)
    return item ~= nil
end

local function IsPolice(source)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end
    return Config.PoliceJobs[Player.PlayerData.job.name] == true
end

local function CanJoinChannel(source, channel)
    if channel == Config.PoliceChannel then
        return IsPolice(source)
    end
    return true
end

local function IsOnCooldown(source)
    local now = GetGameTimer()
    if lastChannelChange[source] and (now - lastChannelChange[source]) < CHANNEL_CHANGE_COOLDOWN then
        return true
    end
    lastChannelChange[source] = now
    return false
end

exports['pma-voice']:addChannelCheck(Config.PoliceChannel, function(source)
    return IsPolice(source)
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    exports['pma-voice']:addChannelCheck(Config.PoliceChannel, function(source)
        return IsPolice(source)
    end)
end)

AddEventHandler('playerDropped', function()
    local src = source
    lastChannelChange[src] = nil
end)

QBCore.Functions.CreateUseableItem(Config.RadioItem, function(source, item)
    local src = source
    if not IsPlayerRadioReady(src) then
        TriggerClientEvent('QBCore:Notify', src, 'You do not have a radio.', 'error')
        return
    end

    if IsPlayerDead(src) then
        TriggerClientEvent('QBCore:Notify', src, 'You cannot use a radio while dead.', 'error')
        return
    end

    TriggerClientEvent('qb-radio:client:openDevice', src)
end)

RegisterNetEvent('qb-radio:server:setChannel', function(channel)
    local src = source
    channel = tonumber(channel)

    if not channel then
        TriggerClientEvent('QBCore:Notify', src, 'Invalid frequency.', 'error')
        return
    end

    if channel < Config.MinChannel or channel > Config.MaxChannel then
        TriggerClientEvent('QBCore:Notify', src, 'Frequency must be ' .. Config.MinChannel .. '-' .. Config.MaxChannel .. '.', 'error')
        return
    end

    if not IsPlayerRadioReady(src) then
        TriggerClientEvent('QBCore:Notify', src, 'You do not have a radio.', 'error')
        return
    end

    if IsPlayerDead(src) then
        TriggerClientEvent('QBCore:Notify', src, 'You cannot use a radio while dead.', 'error')
        return
    end

    if not CanJoinChannel(src, channel) then
        TriggerClientEvent('QBCore:Notify', src, 'Access denied to channel ' .. channel .. '.', 'error')
        TriggerClientEvent('qb-radio:client:rejected', src)
        return
    end

    if IsOnCooldown(src) then
        TriggerClientEvent('QBCore:Notify', src, 'Please wait before changing frequency.', 'error')
        return
    end

    exports['pma-voice']:setPlayerRadio(src, channel)
    TriggerClientEvent('QBCore:Notify', src, 'Tuned to ' .. tostring(channel) .. ' MHz.', 'success')
    TriggerEvent('qb-radio:server:channelChanged', src, channel)
end)

RegisterNetEvent('qb-radio:server:off', function()
    local src = source
    if not IsPlayerRadioReady(src) then return end

    exports['pma-voice']:setPlayerRadio(src, 0)
    TriggerClientEvent('QBCore:Notify', src, 'Radio turned off.', 'primary')
    TriggerEvent('qb-radio:server:channelChanged', src, 0)
end)

-- Instantly drop the player from the radio the moment death metadata flips to true
CreateThread(function()
    while true do
        Wait(1000)

        for _, src in ipairs(GetPlayers()) do
            src = tonumber(src)

            local qbPlayer = QBCore.Functions.GetPlayer(src)
            if qbPlayer then
                local dead = qbPlayer.PlayerData.metadata['isdead'] == true
                    or qbPlayer.PlayerData.metadata['inlaststand'] == true
                    or Player(src).state.isDead == true
                    or Player(src).state.isdead == true
                    or Player(src).state.inlaststand == true
                    or Player(src).state.inLastStand == true

                if dead then
                    local channel = Player(src).state.radioChannel or 0
                    if channel > 0 then
                        exports['pma-voice']:setPlayerRadio(src, 0)
                        TriggerEvent('qb-radio:server:channelChanged', src, 0)
                    end
                end
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    exports['pma-voice']:removeChannelCheck(Config.PoliceChannel)
end)
