Config = {}

Config.MinChannel = 1
Config.MaxChannel = 999

Config.PoliceChannel = 1
Config.PoliceJobs = { ['police'] = true }

Config.RadioItem = 'radio'

Config.DefaultVolume = 50
Config.MinVolume = 0
Config.MaxVolume = 100

Config.PrimaryColor = '#D6AA4BD1'
Config.PrimaryRGB = '214, 170, 75'

Config.Animations = {
    { name = 'Radio Hold',    dict = 'random@arrests',                      anim = 'generic_radio_enter' },
    { name = 'Phone Style',   dict = 'cellphone@',                          anim = 'cellphone_call_in' },
}
