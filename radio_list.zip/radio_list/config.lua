Config = {}

Config.RadioListPosition = {
    right = '2%',
    top = '35%'
}

Config.RadioListEnabled = true

Config.MaxRadioNameLength = 20
Config.MaxDeviceNameLength = 24

Config.DisplayName = 'Radio'
