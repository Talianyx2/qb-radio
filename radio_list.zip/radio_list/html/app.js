const listEl = document.getElementById('radio-list');
const titleEl = document.querySelector('.rl-title');
const freqEl = document.getElementById('rl-freq');
const countEl = document.getElementById('rl-count');
const membersEl = document.getElementById('rl-members');

let displayName = 'Radio';
let radioName = null;
let primaryColor = '#D6AA4B';

function setHidden(hidden) {
    listEl.classList.toggle('hidden', hidden);
    listEl.classList.toggle('visible', !hidden);
}

function render(channel, members) {
    if (!channel || !members || members.length === 0) {
        setHidden(true);
        return;
    }

    titleEl.textContent = radioName || displayName;
    freqEl.textContent = channel;
    countEl.textContent = members.length;
    setHidden(false);

    membersEl.innerHTML = '';

    members.forEach((member) => {
        const li = document.createElement('li');
        li.className = 'rl-member' + (member.talking ? ' talking' : '');

        const dot = document.createElement('span');
        dot.className = 'rl-dot';

        const name = document.createElement('span');
        name.className = 'rl-name';
        name.textContent = member.name || 'Unknown';

        li.appendChild(dot);
        li.appendChild(name);

        if (member.self) {
            const selfTag = document.createElement('span');
            selfTag.className = 'rl-self';
            selfTag.textContent = 'YOU';
            li.appendChild(selfTag);
        }

        if (member.talking && member.self) {
            const talkTag = document.createElement('span');
            talkTag.className = 'rl-talk';
            talkTag.textContent = 'MIC';
            li.appendChild(talkTag);
        }

        membersEl.appendChild(li);
    });
}

window.addEventListener('message', (event) => {
    const data = event.data || {};

    if (data.action === 'config') {
        displayName = data.displayName || displayName;
        primaryColor = data.primaryColor || primaryColor;
        if (data.position) {
            const root = document.documentElement;
            root.style.setProperty('--rl-right', data.position.right || '2%');
            root.style.setProperty('--rl-top', data.position.top || '35%');
        }
    } else if (data.action === 'show') {
        radioName = data.radioName || radioName;
        render(data.channel, data.members);
    } else if (data.action === 'hide') {
        setHidden(true);
    }
});