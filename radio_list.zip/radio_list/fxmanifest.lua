fx_version 'cerulean'
game 'gta5'

name 'Radio list'
author 'Taliany'
description 'Created by Taliany'
version '1.0'

lua54 'yes'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
}

dependencies {
    'qb-core',
    'pma-voice',
    'oxmysql',
}
