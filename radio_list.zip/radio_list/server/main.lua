local QBCore = exports['qb-core']:GetCoreObject()

local customNames = {}
local customDeviceNames = {}

CreateThread(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS player_radio_names (
            citizenid VARCHAR(50) PRIMARY KEY,
            radio_name VARCHAR(64) NOT NULL DEFAULT '',
            radio_dev_name VARCHAR(64) NOT NULL DEFAULT ''
        )
    ]])

    local columns = MySQL.query.await([[
        SELECT COLUMN_NAME FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'player_radio_names'
    ]])

    local hasRadioName = false
    local hasDevName = false
    for i = 1, #columns do
        if columns[i].COLUMN_NAME == 'radio_name' then
            hasRadioName = true
        elseif columns[i].COLUMN_NAME == 'radio_dev_name' then
            hasDevName = true
        end
    end

    if not hasRadioName then
        MySQL.query.await([[ALTER TABLE player_radio_names ADD COLUMN radio_name VARCHAR(64) NOT NULL DEFAULT '']])
    end
    MySQL.query.await([[ALTER TABLE player_radio_names MODIFY radio_name VARCHAR(64) NOT NULL DEFAULT '']])

    if not hasDevName then
        MySQL.query.await([[ALTER TABLE player_radio_names ADD COLUMN radio_dev_name VARCHAR(64) NOT NULL DEFAULT '']])
    end
    MySQL.query.await([[ALTER TABLE player_radio_names MODIFY radio_dev_name VARCHAR(64) NOT NULL DEFAULT '']])

    local result = MySQL.query.await('SELECT citizenid, radio_name, radio_dev_name FROM player_radio_names')
    for i = 1, #result do
        local row = result[i]
        if row.radio_name and row.radio_name ~= '' then
            customNames[row.citizenid] = row.radio_name
        end
        if row.radio_dev_name and row.radio_dev_name ~= '' then
            customDeviceNames[row.citizenid] = customDeviceNames[row.citizenid] or {}
            customDeviceNames[row.citizenid][tostring(0)] = row.radio_dev_name
        end
    end

    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS player_radio_dev_names (
            citizenid VARCHAR(50) NOT NULL,
            channel VARCHAR(20) NOT NULL,
            dev_name VARCHAR(64) NOT NULL DEFAULT '',
            PRIMARY KEY (citizenid, channel)
        )
    ]])

    local devResult = MySQL.query.await('SELECT citizenid, channel, dev_name FROM player_radio_dev_names')
    for i = 1, #devResult do
        local row = devResult[i]
        if row.dev_name and row.dev_name ~= '' then
            customDeviceNames[row.citizenid] = customDeviceNames[row.citizenid] or {}
            customDeviceNames[row.citizenid][row.channel] = row.dev_name
        end
    end
end)

local function GetCitizenId(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return nil end
    return Player.PlayerData.citizenid
end

local function SanitizeName(raw, maxLen)
    if type(raw) ~= 'string' then return nil end
    local name = raw:gsub('^%s+', ''):gsub('%s+$', '')
    if name == '' then return nil end

    name = name:gsub('[%c<>\\`"]', '')

    local len = utf8.len(name)
    if not len then return nil end

    if len > maxLen then
        name = utf8.sub(name, 1, maxLen)
    end

    return name
end

local function GetCustomName(src)
    local cid = GetCitizenId(src)
    if not cid then return nil end
    return customNames[cid]
end

RegisterNetEvent('radio_list:server:getNames', function(sources)
    local src = source
    if type(sources) ~= 'table' then return end

    local result = {}
    for i = 1, #sources do
        local s = tonumber(sources[i])
        if s then
            local name = GetCustomName(s)
            if name then result[tostring(s)] = name end
        end
    end

    TriggerClientEvent('radio_list:client:updateNames', src, result)
end)

RegisterCommand('nameinradio', function(source, args, rawCommand)
    local src = source
    local raw = table.concat(args or {}, ' ')
    local name = SanitizeName(raw, Config.MaxRadioNameLength)

    if not name then
        TriggerClientEvent('QBCore:Notify', src, 'Invalid radio name. Name cannot be empty or contain < > \\ " or control characters.', 'error')
        return
    end

    local cid = GetCitizenId(src)
    if not cid then return end

    MySQL.insert.await([[
        INSERT INTO player_radio_names (citizenid, radio_name)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE radio_name = VALUES(radio_name)
    ]], { cid, name })

    customNames[cid] = name

    TriggerClientEvent('QBCore:Notify', src, 'Radio name set to: ' .. name, 'success')
    TriggerClientEvent('radio_list:client:updateName', -1, src, name)
end, false)

RegisterCommand('nameofradio', function(source, args, rawCommand)
    local src = source
    local raw = table.concat(args or {}, ' ')
    local name = SanitizeName(raw, Config.MaxDeviceNameLength)

    if not name then
        TriggerClientEvent('QBCore:Notify', src, 'Invalid radio name. Name cannot be empty or contain < > \\ " or control characters.', 'error')
        return
    end

    local channel = Player(src).state.radioChannel
    if not channel or channel <= 0 then
        TriggerClientEvent('QBCore:Notify', src, 'Join a radio channel first.', 'error')
        return
    end

    local cid = GetCitizenId(src)
    if not cid then return end

    local channelKey = tostring(channel)

    MySQL.insert.await([[
        INSERT INTO player_radio_dev_names (citizenid, channel, dev_name)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE dev_name = VALUES(dev_name)
    ]], { cid, channelKey, name })

    customDeviceNames[cid] = customDeviceNames[cid] or {}
    customDeviceNames[cid][channelKey] = name

    TriggerClientEvent('QBCore:Notify', src, 'Channel ' .. channelKey .. ' name set to: ' .. name, 'success')
    TriggerClientEvent('radio_list:client:updateDeviceName', src, channelKey, name)
end, false)

RegisterNetEvent('radio_list:server:getDeviceName', function(channelKey)
    local src = source
    if type(channelKey) ~= 'string' then
        channelKey = tostring(channelKey or '')
    end

    local cid = GetCitizenId(src)
    local name
    if cid and customDeviceNames[cid] then
        name = customDeviceNames[cid][channelKey]
    end

    TriggerClientEvent('radio_list:client:deviceName', src, channelKey, name)
end)