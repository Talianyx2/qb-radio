local localPlyId = GetPlayerServerId(PlayerId())

local currentChannel = 0
local inChannel = false

local members = {}
local customNames = {}
local myChannelNames = {}

local function GetChannelName(channel)
    if channel > 0 then
        local name = myChannelNames[tostring(channel)]
        if name and name ~= '' then
            return name
        end
    end
    return Config.DisplayName
end

local function RequestDeviceName(channel)
    if channel > 0 then
        TriggerServerEvent('radio_list:server:getDeviceName', tostring(channel))
    end
end

local function GetDefaultName(src)
    return GetPlayerName(src) or ('Player_' .. src)
end

local function SendList()
    if not Config.RadioListEnabled then
        SendNUIMessage({ action = 'hide' })
        return
    end

    if not inChannel or currentChannel <= 0 or not next(members) then
        SendNUIMessage({ action = 'hide' })
        return
    end

    local list = {}
    for src, member in pairs(members) do
        list[#list + 1] = {
            name = customNames[src] or GetDefaultName(src),
            talking = member.talking == true,
            self = src == localPlyId,
        }
    end

    SendNUIMessage({
        action = 'show',
        channel = currentChannel,
        radioName = GetChannelName(currentChannel),
        members = list,
    })
end

local function RefreshNames()
    local sources = {}
    for src, _ in pairs(members) do
        sources[#sources + 1] = src
    end
    if #sources > 0 then
        TriggerServerEvent('radio_list:server:getNames', sources)
    end
end

--- Syncs the full radio table when joining a channel
RegisterNetEvent('pma-voice:syncRadioData', function(radioTable)
    if type(radioTable) ~= 'table' or not next(radioTable) then
        members = {}
        inChannel = false
        SendList()
        return
    end

    if currentChannel <= 0 then
        currentChannel = LocalPlayer.state.radioChannel or 0
    end

    if currentChannel > 0 then
        inChannel = true
    end

    members = {}
    for src, talking in pairs(radioTable) do
        src = tonumber(src)
        if src then
            members[src] = { talking = talking == true }
        end
    end

    RequestDeviceName(currentChannel)
    RefreshNames()
    SendList()
end)

--- A player joined our channel
RegisterNetEvent('pma-voice:addPlayerToRadio', function(src)
    src = tonumber(src)
    if not src then return end
    inChannel = true
    if not members[src] then
        members[src] = { talking = false }
        RefreshNames()
    end
    SendList()
end)

--- A player (or us) left the channel
RegisterNetEvent('pma-voice:removePlayerFromRadio', function(src)
    src = tonumber(src)
    if not src then return end
    -- When we switch frequency (95 -> 96), pma-voice removes us from the old
    -- channel. Ignore self-removal here; clSetPlayerRadio + syncRadioData handle it.
    if src == localPlyId then return end
    if members[src] then
        members[src] = nil
        customNames[src] = nil
        SendList()
    end
end)

--- Talking state changed
RegisterNetEvent('pma-voice:setTalkingOnRadio', function(src, talking)
    src = tonumber(src)
    if not src then return end
    if members[src] then
        members[src].talking = talking == true
        SendList()
    end
end)

--- Our channel was set server-side
RegisterNetEvent('pma-voice:clSetPlayerRadio', function(channel)
    currentChannel = tonumber(channel) or 0
    if currentChannel <= 0 then
        members = {}
        inChannel = false
        SendList()
    else
        inChannel = true
        RequestDeviceName(currentChannel)
    end
end)

--- Our channel change was rejected
RegisterNetEvent('pma-voice:radioChangeRejected', function()
    members = {}
    currentChannel = 0
    inChannel = false
    SendList()
end)

--- Custom names response for our current channel members
RegisterNetEvent('radio_list:client:updateNames', function(nameMap)
    if type(nameMap) ~= 'table' then return end
    for key, name in pairs(nameMap) do
        local src = tonumber(key)
        if src and name then
            customNames[src] = name
        end
    end
    SendList()
end)

--- A player changed their radio name somewhere
RegisterNetEvent('radio_list:client:updateName', function(src, name)
    src = tonumber(src)
    if not src or not name then return end
    customNames[src] = name
    if members[src] then
        SendList()
    end
end)

--- Our radio device name changed for a channel
RegisterNetEvent('radio_list:client:updateDeviceName', function(channelKey, name)
    channelKey = tostring(channelKey or '')
    if channelKey == '' then return end
    myChannelNames[channelKey] = name
    SendList()
end)

--- Our channel device name from the server
RegisterNetEvent('radio_list:client:deviceName', function(channelKey, name)
    channelKey = tostring(channelKey or '')
    if channelKey == '' then return end
    if name and name ~= '' then
        myChannelNames[channelKey] = name
    else
        myChannelNames[channelKey] = nil
    end
    SendList()
end)

CreateThread(function()
    Wait(500)
    SendNUIMessage({
        action = 'config',
        position = Config.RadioListPosition,
        displayName = Config.DisplayName,
        primaryColor = '#D6AA4BD1',
    })
    Wait(100)
    RequestDeviceName(currentChannel)
    Wait(200)
    SendList()
end)

CreateThread(function()
    Wait(1000)
    TriggerEvent('chat:addSuggestion', '/nameofradio', 'Change the radio name for your current frequency', { { name = 'name', help = 'e.g. GANG YAKURA' } })
    TriggerEvent('chat:addSuggestion', '/nameinradio', 'Change your name shown on the radio channel list', { { name = 'name', help = 'e.g. AYOUB' } })
end)