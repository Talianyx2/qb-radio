fx_version 'cerulean'
game 'gta5'

author 'BattleRace devlopement'
description 'BR HUD - Premium Dark/Gold PvP HUD for QBCore'
version '1.0.0'

lua54 'yes'

shared_script 'config.lua'

client_script 'client/main.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/images/logo.png',
    'html/icons/crown.svg',
    'html/icons/wallet.svg',
    'html/icons/bank.svg',
    'html/icons/users.svg',
    'html/icons/mic.svg',
    'html/icons/mic-off.svg',
    'html/icons/radio.svg',
    'html/icons/hp.svg',
    'html/icons/stamina.svg',
    'html/icons/armor.svg',
    'html/icons/belt-on.svg',
    'html/icons/belt-off.svg'
}