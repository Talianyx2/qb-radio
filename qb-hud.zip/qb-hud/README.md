# VRX HUD

Premium **Dark + Gold** PvP HUD for **QBCore**.

> Built from scratch. Does NOT modify `qb-core`, `pma-voice` or any other resource.

## Features

- **Server Logo** — top-left, configurable (`html/images/logo.png`)
- **Server name** — top-center with animated gold line
- **Player info** — name, ID, job, avatar, voice/radio indicator (top-right)
- **Money** — cash & bank with smooth number animation
- **Online players** — `current / max` auto-update
- **Status bars** — health (red), stamina (yellow), armor (blue), animated; armor hides at 0
- **Minimap** — the default GTA minimap is untouched; a dark/gold frame is drawn around it
- **Voice HUD** — mic / talking / radio states via pma-voice (without touching pma-voice)
- **Bottom-center server bar** — `VRX • ONLINE • 42/128`
- **Vehicle speedometer** — circular dark/gold gauge with speed + gear (KM/H or MPH), auto hides outside vehicle
- **PvP mode** — master gold glow, red health alarm under 40%

## Commands

| Command      | Description                              |
| ------------ | ---------------------------------------- |
| `/hud`       | Toggle the whole HUD                      |
| `/hudedit`   | Enable/disable HUD editor (drag the panels) |
| `/hudreset`  | Reset panel positions                     |

## Installation

1. Copy the `vrx-hud` folder into your server resources.
2. Add this line to `server.cfg` (after `qb-core`):

```cfg
ensure vrx-hud
```

3. **Optional:** replace `vrx-hud/html/images/logo.png` with your real server logo (keep the same filename) and edit `config.lua` (`Config.ServerName`, `Config.ServerLogo`, `Config.ShortName`, colors, positions, ...).
4. Restart the server (or `restart vrx-hud`).

## Configuration

Everything is inside `config.lua`:

- `Config.ServerName` / `Config.ShortName` / `Config.ServerLogo`
- `Config.Colors` — colors + gold glow
- `Config.PvPHud` — master PvP look
- `Config.ShowLogo/ShowServerName/ShowPlayer/ShowJob/ShowMoney/ShowBank/ShowPlayers/ShowStatus/ShowVehicleHud/ShowVoice/ShowMinimap`
- `Config.SpeedUnit` — `kmh` or `mph`
- `Config.Minimap` — `sizeScale`, `offsetX`, `offsetY` (use these to align the minimap frame to your monitor)
- `Config.Positions` — pixel positions for every panel
- `Config.Animations` / `Config.Updates` — timing

> If the minimap frame is slightly off your screen, adjust `Config.Minimap.sizeScale` / `offsetX` / `offsetY`. Everything else is responsive by design.

## Notes

- Uses real FiveM/QBCore data: no hardcoded player info.
- SendNUIMessage is only fired when a value actually changes (except vehicle speed, which updates while in a vehicle).
- If QBCore money is provided by another script via a different event, the money panel may not update — the default `QBCore:Client:OnMoneyChange` is used.

## Requirements

- FiveM (GTA5)
- [qb-core] (required)
- [pma-voice] (optional — enables the voice/radio state)