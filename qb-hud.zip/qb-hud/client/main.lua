local QBCore = exports['qb-core']:GetCoreObject()

print('[vrx-hud] client script started')

local hudEnabled = true
local editMode = false

local lastStatus = { -1, -1, -1 }
local lastPaused = nil
local lastVoice = { voiceStarted = nil, talking = false, radio = false }

local moneyCache = { cash = 0, bank = 0 }

-- hide the default GTA V HUD (health / armor / money / minimap)
CreateThread(function()
    while true do
        if Config.HideGameHud then
            DisplayHud(false)
        end
        if Config.HideMinimap then
            DisplayRadar(false)
        end
        Wait(0)
    end
end)

--------------------------------------------------------------
-- NUI HELPERS
--------------------------------------------------------------
local function send(action, data)
    SendNUIMessage({ action = action, data = data })
end

local function SendMoney()
    send('updateMoney', {
        cash = math.max(0, moneyCache.cash or 0),
        bank = math.max(0, moneyCache.bank or 0)
    })
end

local function FormatJob(job)
    if not job then return 'Unemployed' end
    local label = job.label or 'Unemployed'
    local grade = job.grade and job.grade.name
    if grade and grade ~= '' then
        return label .. ' | ' .. grade
    end
    return label
end

local function SendPlayer()
    local pdata = QBCore.Functions.GetPlayerData()
    if not pdata or not pdata.charinfo then return end

    local money = pdata.money or {}
    moneyCache.cash = money.cash or 0
    moneyCache.bank = money.bank or 0

    local level = 0
    if pdata.metadata then
        level = tonumber(pdata.metadata.level or pdata.metadata['level'] or 0) or 0
    end

    send('updatePlayer', {
        name = tostring(pdata.charinfo.firstname or 'Unknown') .. ' ' .. tostring(pdata.charinfo.lastname or ''),
        id = GetPlayerServerId(PlayerId()),
        job = FormatJob(pdata.job),
        level = level,
        avatar = pdata.charinfo.picture or nil,
        loaded = true
    })
    SendMoney()
end

--------------------------------------------------------------
-- INIT / SETUP
--------------------------------------------------------------
local setupAcked = false

local function SendSetup()
    print('[vrx-hud] sending setup to NUI')
    local scale = CalculateMinimapScale() or 0.9
    local mw = scale * 0.243 * Config.Minimap.sizeScale
    local mh = mw * 1.16
    local mx = math.max(0, 1.0 - mw - 0.021) + Config.Minimap.offsetX
    local my = math.max(0, 1.0 - mh - 0.011) + Config.Minimap.offsetY

    send('setup', {
        serverName  = Config.ServerName,
        brandingSub = Config.BrandingSub,
        shortName   = Config.ShortName,
        logo        = Config.ServerLogo,
        colors      = Config.Colors,
        animations  = Config.Animations,
        positions   = Config.Positions,
        speedUnit   = Config.SpeedUnit,
        speedoMax   = Config.SpeedometerMax,
        pvp         = Config.PvPHud,
        show = {
            topleft  = Config.ShowClock,
            branding = Config.ShowServerName,
            player   = Config.ShowPlayer,
            job      = Config.ShowJob,
            cash     = Config.ShowMoney,
            bank     = Config.ShowBank,
            players  = Config.ShowPlayers,
            status   = Config.ShowStatus,
            vehicle  = Config.ShowVehicleHud,
            voice    = Config.ShowVoice,
            minimap  = Config.ShowMinimap,
            minimapFrame = Config.ShowMinimapFrame
        },
        minimap = { x = mx, y = my, w = mw, h = mh }
    })
end

RegisterNUICallback('ready', function(_, cb)
    setupAcked = true
    print('[vrx-hud] NUI acknowledged setup')
    cb('ok')
end)

RegisterNUICallback('nuiError', function(data, cb)
    if data and data.message then
        print('[vrx-hud] NUI error: ' .. tostring(data.message))
    end
    cb('ok')
end)

CreateThread(function()
    Wait(500)

    SendSetup()

    local attempts = 0
    while not setupAcked and attempts < 30 do
        Wait(1000)
        if not setupAcked then SendSetup() end
        attempts = attempts + 1
    end

    while not QBCore.PlayerData or not QBCore.PlayerData.charinfo do
        Wait(500)
    end

    local idTries = 0
    while GetPlayerServerId(PlayerId()) == 0 and idTries < 10 do
        Wait(500)
        idTries = idTries + 1
    end

    SendPlayer()
end)

--------------------------------------------------------------
-- QBCORE EVENTS
--------------------------------------------------------------
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    SendPlayer()
end)

RegisterNetEvent('QBCore:Client:OnPlayerUnload', function()
    send('updatePlayer', { loaded = false })
end)

RegisterNetEvent('QBCore:Client:OnMoneyChange', function(moneytype, amount, action, reason)
    if not moneytype or amount == nil then return end

    if moneytype == 'cash' then
        if action == 'add' then
            moneyCache.cash = moneyCache.cash + amount
        elseif action == 'remove' then
            moneyCache.cash = moneyCache.cash - amount
        else
            moneyCache.cash = amount
        end
        SendMoney()
    elseif moneytype == 'bank' then
        if action == 'add' then
            moneyCache.bank = moneyCache.bank + amount
        elseif action == 'remove' then
            moneyCache.bank = moneyCache.bank - amount
        else
            moneyCache.bank = amount
        end
        SendMoney()
    end
end)

AddEventHandler('QBCore:Client:OnPlayerUpdated', function(key, val)
    if not key then return end

    if key == 'all' and val then
        if val.money then
            moneyCache.cash = val.money.cash or moneyCache.cash
            moneyCache.bank = val.money.bank or moneyCache.bank
        end
        SendMoney()
        if val.charinfo then SendPlayer() end
    elseif key == 'money' then
        if val then
            moneyCache.cash = val.cash or moneyCache.cash
            moneyCache.bank = val.bank or moneyCache.bank
        end
        SendMoney()
    elseif key == 'job' then
        local job = val or (QBCore.Functions.GetPlayerData() or {}).job
        if job and job.label then
            send('updateJob', { job = FormatJob(job) })
        end
    end
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(job)
    if job and job.label then
        send('updateJob', { job = FormatJob(job) })
    end
end)

--------------------------------------------------------------
-- PLAYER ID HEARTBEAT (keeps the HUD in sync with the real server ID)
--------------------------------------------------------------
CreateThread(function()
    local lastServerId = nil

    while true do
        local id = GetPlayerServerId(PlayerId())
        if id ~= lastServerId then
            lastServerId = id
            print('[vrx-hud] server id: ' .. tostring(id))
            send('updatePlayer', { id = id })
        end
        Wait(5000)
    end
end)

--------------------------------------------------------------
-- CLOCK (time / date)
--------------------------------------------------------------
CreateThread(function()
    while true do
        local t = os.date('*t')
        send('updateClock', {
            time = string.format('%02d:%02d', t.hour, t.min),
            date = string.format('%d/%d/%d', t.day, t.month, t.year)
        })
        Wait(1000)
    end
end)

--------------------------------------------------------------
-- STATUS (health / stamina / armor)
--------------------------------------------------------------
CreateThread(function()
    while true do
        if Config.ShowStatus then
            local ped = PlayerPedId()

            local health = math.ceil((GetEntityHealth(ped) / GetEntityMaxHealth(ped)) * 100)
            local stamina = math.floor(GetPlayerStamina(PlayerId()))
            local armor = GetPedArmour(ped)

            health = math.max(0, math.min(100, health))
            stamina = math.max(0, math.min(100, stamina))
            armor = math.max(0, math.min(100, armor))

            if health ~= lastStatus[1] or stamina ~= lastStatus[2] or armor ~= lastStatus[3] then
                lastStatus = { health, stamina, armor }
                send('updateStatus', {
                    health = health,
                    stamina = stamina,
                    armor = armor
                })
            end
        end
        Wait(Config.Updates.status)
    end
end)

--------------------------------------------------------------
-- ONLINE PLAYERS
--------------------------------------------------------------
CreateThread(function()
    local lastCount = -1
    local Max = GetConvarInt('sv_maxclients', Config.MaxPlayers)

    while true do
        local current = GetNumPlayerIndices()
        if current ~= lastCount then
            lastCount = current
            send('updatePlayers', { current = current, max = Max })
        end
        Wait(Config.Updates.players)
    end
end)

--------------------------------------------------------------
-- VOICE (pma-voice, without modifying it)
--------------------------------------------------------------
CreateThread(function()
    while true do
        if Config.ShowVoice then
            local started = GetResourceState(Config.VoiceResource) == 'started'

            if started then
                local talking = MumbleIsPlayerTalking(PlayerId()) == 1
                local radio = LocalPlayer.state.radioActive == true

                if lastVoice.voiceStarted ~= true or talking ~= lastVoice.talking or radio ~= lastVoice.radio then
                    lastVoice = { voiceStarted = true, talking = talking, radio = radio }
                    send('updateVoice', { talking = talking, radio = radio, enabled = true })
                end
            elseif lastVoice.voiceStarted ~= false then
                lastVoice = { voiceStarted = false, talking = false, radio = false }
                send('updateVoice', { talking = false, radio = false, enabled = false })
            end
        end
        Wait(Config.VoicePollRate)
    end
end)

--------------------------------------------------------------
-- SEATBELT (uses the existing qb-smallresources seatbelt system)
--------------------------------------------------------------
local seatbeltOn = false

RegisterNetEvent('seatbelt:client:ToggleSeatbelt', function(on)
    seatbeltOn = on == true
end)

--------------------------------------------------------------
-- VEHICLE / SPEEDOMETER
--------------------------------------------------------------
CreateThread(function()
    local visible = false
    local lastSpeed = -1
    local lastGear = -1
    local lastBelt = nil
    local prevRaw = 0
    local factor = Config.SpeedUnit == 'mph' and 2.236936 or 3.6

    while true do
        local inVehicle = false
        local wait = 800

        if Config.ShowVehicleHud then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)

            if veh ~= 0 then
                inVehicle = true
                wait = Config.Updates.vehicle

                local raw = GetEntitySpeed(veh)
                local speed = math.floor(raw * factor)
                local gear = GetVehicleCurrentGear(veh)

                local arrow = 'none'
                if raw > prevRaw + 0.1 then
                    arrow = 'up'
                elseif raw < prevRaw - 0.1 then
                    arrow = 'down'
                end
                prevRaw = raw

                local belt = seatbeltOn

                if speed ~= lastSpeed or gear ~= lastGear or arrow ~= 'none' or belt ~= lastBelt then
                    lastSpeed = speed
                    lastGear = gear
                    lastBelt = belt

                    if not visible then
                        visible = true
                    end

                    send('updateVehicle', {
                        speed = speed,
                        gear = gear,
                        unit = Config.SpeedUnit,
                        arrow = arrow,
                        belt = belt,
                        visible = true
                    })
                end
            end
        end

        if not inVehicle and visible then
            visible = false
            lastSpeed = -1
            lastGear = -1
            lastBelt = nil
            prevRaw = 0
            send('updateVehicle', { visible = false })
        end

        Wait(wait)
    end
end)

--------------------------------------------------------------
-- PAUSE MENU (hide HUD while paused)
--------------------------------------------------------------
CreateThread(function()
    while true do
        local paused = IsPauseMenuActive()
        if paused ~= lastPaused then
            lastPaused = paused
            send('setPaused', { paused = paused })
        end
        Wait(500)
    end
end)

--------------------------------------------------------------
-- COMMANDS
--------------------------------------------------------------
RegisterCommand(Config.Commands.Toggle, function()
    hudEnabled = not hudEnabled
    send('toggleVisibility', { visible = hudEnabled })
    QBCore.Functions.Notify(hudEnabled and 'HUD enabled.' or 'HUD disabled.', hudEnabled and 'success' or 'error')
end, false)

RegisterCommand(Config.Commands.Edit, function()
    editMode = not editMode
    send('setEditMode', { enabled = editMode })
    QBCore.Functions.Notify(editMode and 'HUD editor enabled - drag any panel.' or 'HUD editor disabled.', 'primary')
end, false)

RegisterCommand(Config.Commands.Reset, function()
    send('resetHud', {})
    QBCore.Functions.Notify('HUD positions reset.', 'success')
end, false)

for _, command in pairs(Config.Commands) do
    TriggerEvent('chat:addSuggestion', '/' .. command, 'VRX HUD command')
end