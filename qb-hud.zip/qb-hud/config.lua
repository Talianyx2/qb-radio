Config = {}

-----------------------------------------------------------
-- SERVER BRANDING
-----------------------------------------------------------
Config.HideGameHud = true  -- hide the default GTA health / armor / money / stamina HUD
Config.HideMinimap = true  -- hide the GTA minimap (radar)
Config.ShowMinimapFrame = false -- draw the VRX gold frame around the minimap

Config.ServerName = 'VRX'
Config.ServerLogo = 'logo.png' -- OPTIONAL: replace brand icon (PNG/GIF) - put logo.gif and set 'logo.gif'
Config.BrandingSub = 'ROLEPLAY'
Config.ShortName  = 'VRX'

-----------------------------------------------------------
-- COLORS (Dark + Gold theme)
-----------------------------------------------------------
Config.Colors = {
    primary   = '#D6AA4B',
    secondary = '#0B0B0B',
    font      = '#FFFFFF',
    red       = '#E74C3C',
    yellow    = '#F1C40F',
    blue      = '#3498DB',
    green     = '#2ECC71',
    goldGlow  = 'rgba(214, 170, 75, 0.45)'
}

-----------------------------------------------------------
-- SHOW / HIDE COMPONENTS
-----------------------------------------------------------
Config.PvPHud           = true  -- master switch for the premium PvP look (bars + glow)
Config.ShowClock        = true  -- top-left time / date panel
Config.ShowServerName   = true  -- top-right server branding (name + ROLEPLAY)
Config.ShowPlayer       = true
Config.ShowJob          = true
Config.ShowMoney        = true  -- wallet card
Config.ShowBank         = true  -- bank card
Config.ShowPlayers      = true  -- player count row in the top-left panel
Config.ShowStatus       = true -- health / stamina / armor bars
Config.ShowVehicleHud   = true
Config.ShowVoice        = true -- mic / radio indicator inside the player card
Config.ShowMinimap      = true -- draws a dark/gold frame around the default minimap

-----------------------------------------------------------
-- ANIMATION SETTINGS (milliseconds)
-----------------------------------------------------------
Config.Animations = {
    barSpeed   = 350,   -- progress bar transition
    numberSpeed = 450,  -- money / speed number tween
    fadeSpeed  = 300,   -- panel fade in/out
    glowPulse  = 2.2    -- seconds for one gold glow pulse
}

-----------------------------------------------------------
-- VEHICLE / SPEED
-----------------------------------------------------------
Config.SpeedUnit = 'kmh' -- 'kmh' or 'mph'
Config.SpeedometerMax = 200 -- km/h at which the gold ring reaches 100% of the gauge

-- SEATBELT indicator:
-- Uses the EXISTING qb-smallresources seatbelt system (no duplicate is created).
-- Default key: G  (can be re-bound by players in: Settings > Key Bindings > "Toggle Seatbelt")
-- The indicator only reflects the built-in seatbelt state (on/off).

-----------------------------------------------------------
-- MINIMAP FRAME
-----------------------------------------------------------
-- The frame is drawn on top of the default GTA minimap (the game minimap is NOT replaced).
-- It is positioned with proportions of the screen, so it works on most 16:9 monitors.
-- If it does not align perfectly on your monitor, tweak the values below.
Config.Minimap = {
    sizeScale = 1.0,
    -- offsets as fractions of screen (0.0 - 1.0); 0 = default corner position
    offsetX = 0.0,
    offsetY = 0.0
}

-----------------------------------------------------------
-- PANEL POSITIONS (pixels from the screen edges)
-----------------------------------------------------------
Config.Positions = {
    topleft     = { left = 24, top = 24 },
    branding    = { right = 24, top = 24 },
    player      = { right = 24, top = 130 },
    wallet      = { right = 24, top = 236 },
    bank        = { right = 24, top = 320 },
    status      = { left = 24, bottom = 30 },
    speedometer = { right = 30, bottom = 80 } -- circular gauge, bottom right of the screen
}

-----------------------------------------------------------
-- COMMANDS
-----------------------------------------------------------
Config.Commands = {
    Toggle = 'hud',
    Reset  = 'hudreset',
    Edit   = 'hudedit'
}

-----------------------------------------------------------
-- VOICE
-----------------------------------------------------------
Config.VoiceResource = 'pma-voice'
Config.VoicePollRate = 300 -- ms between voice status checks

-----------------------------------------------------------
-- FALLBACKS
-----------------------------------------------------------
Config.MaxPlayers = 64 -- used only if sv_maxclients is not readable

-----------------------------------------------------------
-- UPDATE RATES (ms)
-----------------------------------------------------------
Config.Updates = {
    players = 3000,
    status  = 200,
    vehicle = 100
}