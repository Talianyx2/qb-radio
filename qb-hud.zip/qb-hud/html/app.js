/* global document, window */

const state = {
    cfg: null,
    toggleHidden: false,
    paused: false,
    editMode: false,
    unit: 'KM/H'
};

const $ = (id) => document.getElementById(id);

const POS_MAP = {
    topleft: 'topleft',
    branding: 'branding',
    player: 'player',
    wallet: 'wallet',
    bank: 'bank',
    status: 'status',
    speedometer: 'speedometer'
};

/* ---------------- helpers ---------------- */

function fmt(n) {
    return Number(n || 0).toLocaleString('en-US');
}

function moneyText(n) {
    return fmt(Math.max(0, Math.round(n))) + '$';
}

function tweenNumber(el, to, dur) {
    if (!el) return;
    to = Math.max(0, Math.round(to));
    const from = Number(el.dataset.value || 0);
    if (from === to) { el.textContent = moneyText(to); el.dataset.value = to; return; }

    const start = performance.now();
    cancelAnimationFrame(el._raf);
    el.dataset.value = to;

    const step = (now) => {
        const t = Math.min(1, (now - start) / dur);
        const eased = 1 - Math.pow(1 - t, 3);
        const cur = Math.round(from + (to - from) * eased);
        el.textContent = moneyText(cur);
        if (t < 1) {
            el._raf = requestAnimationFrame(step);
        } else {
            el.textContent = moneyText(to);
        }
    };

    el._raf = requestAnimationFrame(step);
}

function setHide(el, hide) {
    if (el) el.dataset.hide = hide ? 'true' : 'false';
}

function applyCssVars(cfg) {
    const r = document.documentElement.style;
    const c = cfg.colors || {};
    if (c.primary) r.setProperty('--primary', c.primary);
    if (c.secondary) r.setProperty('--secondary', c.secondary);
    if (c.font) r.setProperty('--font', c.font);
    if (c.red) r.setProperty('--red', c.red);
    if (c.yellow) r.setProperty('--yellow', c.yellow);
    if (c.blue) r.setProperty('--blue', c.blue);
    if (c.green) r.setProperty('--green', c.green);
    if (c.goldGlow) r.setProperty('--glow', c.goldGlow);

    const a = cfg.animations || {};
    if (a.barSpeed) r.setProperty('--bar-speed', a.barSpeed + 'ms');
    if (a.fadeSpeed) r.setProperty('--fade-speed', a.fadeSpeed + 'ms');
    if (a.glowPulse) r.setProperty('--pulse-speed', a.glowPulse + 's');
}

function applyPositions() {
    if (!state.cfg) return;

    const positions = state.cfg.positions || {};

    for (const [key, id] of Object.entries(POS_MAP)) {
        const el = $(id);
        if (!el || !positions[key]) continue;

        el.style.left = '';
        el.style.top = '';
        el.style.right = '';
        el.style.bottom = '';
        el.style.transform = '';

        const p = positions[key];
        if (p.center === true) {
            el.style.left = '50%';
            el.style.transform = 'translateX(-50%)';
            if (p.top !== undefined) el.style.top = p.top + 'px';
            if (p.bottom !== undefined) el.style.bottom = p.bottom + 'px';
        } else {
            if (p.left !== undefined) el.style.left = p.left + 'px';
            if (p.right !== undefined) el.style.right = p.right + 'px';
            if (p.top !== undefined) el.style.top = p.top + 'px';
            if (p.bottom !== undefined) el.style.bottom = p.bottom + 'px';
        }
    }
}

function applyMinimapFrame() {
    const frame = $('minimap-frame');
    const mm = state.cfg && state.cfg.minimap;
    if (!frame || !mm) return;
    frame.style.width = (mm.w * 100) + '%';
    frame.style.height = (mm.h * 100) + '%';
    frame.style.left = (mm.x * 100) + '%';
    frame.style.top = (mm.y * 100) + '%';
}

/* ---------------- avatar ---------------- */

function applyAvatar(name, picture) {
    const letter = $('avatar-letter');
    const img = $('avatar-img');
    if (!letter || !img) return;

    if (picture && typeof picture === 'string' && picture.length > 4) {
        img.src = picture;
        img.style.display = 'block';
        letter.style.display = 'none';
    } else {
        img.style.display = 'none';
        letter.style.display = 'flex';
        const first = name ? name.trim().charAt(0).toUpperCase() : 'P';
        letter.textContent = first;
    }
}

/* ---------------- drag / edit mode ---------------- */

let dragEl = null;
let dragStart = null;

function onPointerDown(e) {
    if (!state.editMode) return;
    const target = e.target.closest('.hud-card,.speedo-panel');
    if (!target) return;
    dragEl = target;
    dragStart = { x: e.clientX, y: e.clientY, lx: dragEl.offsetLeft, ty: dragEl.offsetTop };
    e.preventDefault();
}

function onPointerMove(e) {
    if (!dragEl || !dragStart) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;

    dragEl.style.left = (dragStart.lx + dx) + 'px';
    dragEl.style.top = (dragStart.ty + dy) + 'px';
    dragEl.style.right = '';
    dragEl.style.bottom = '';
    dragEl.style.transform = '';
}

function onPointerUp() {
    dragEl = null;
    dragStart = null;
}

function applyEditMode(enabled) {
    state.editMode = enabled;
    const root = $('hud-root');
    root.classList.toggle('editing', enabled);
}

/* ---------------- NUI messages ---------------- */

function setup(data) {
    state.cfg = data;
    state.unit = (data.speedUnit || 'kmh') === 'mph' ? 'MPH' : 'KM/H';

    applyCssVars(data);
    applyPositions();
    applyMinimapFrame();

    if (data.logo && $('brand-icon') && data.logo !== 'logo.png') {
        $('brand-icon').src = 'images/' + data.logo;
    }
    if (data.serverName && $('server-name')) {
        $('server-name').textContent = data.serverName;
    }
    if (data.brandingSub && $('brand-sub')) {
        $('brand-sub').textContent = data.brandingSub;
    }
    if ($('speedo-unit')) $('speedo-unit').textContent = state.unit;

    $('hud-root').classList.toggle('pvp', !!data.pvp);

    const show = data.show || {};
    setHide($('topleft'), show.topleft !== true);
    setHide($('info-players'), show.players !== true);
    setHide($('branding'), show.branding !== true);
    setHide($('player'), show.player !== true);
    setHide($('wallet'), show.cash !== true);
    setHide($('bank'), show.bank !== true);
    setHide($('status'), show.status !== true);
    setHide($('speedometer'), show.vehicle !== true);
    setHide($('minimap-frame'), show.minimapFrame !== true);
    setHide($('p-job'), show.job !== true);

    updateVisibility();
}

function updatePlayer(data) {
    if (data.loaded === false) {
        setHide($('player'), true);
        return;
    }
    setHide($('player'), false);

    if (data.name && $('p-name')) $('p-name').textContent = data.name;
    if (data.job && $('p-job')) $('p-job').textContent = data.job;
    if (data.id !== undefined && data.id !== null) {
        if ($('level-num')) $('level-num').textContent = data.id;
        if ($('player-id')) $('player-id').textContent = data.id;
    }

    if (state.cfg && state.cfg.show) {
        setHide($('p-job'), state.cfg.show.job !== true);
    }

    applyAvatar(data.name || '', data.avatar);
}

function updateJob(data) {
    if (data.job && $('p-job')) $('p-job').textContent = data.job;
    if (state.cfg && state.cfg.show) {
        setHide($('p-job'), state.cfg.show.job !== true);
    }
}

function updateMoney(data) {
    const cfg = state.cfg;
    const speed = (cfg && cfg.animations && cfg.animations.numberSpeed) || 450;
    if (cfg && cfg.show) {
        if (cfg.show.cash) tweenNumber($('wallet-value'), data.cash, speed);
        if (cfg.show.bank) tweenNumber($('bank-value'), data.bank, speed);
    }
}

function updateStatus(data) {
    const barSpeed = ((state.cfg && state.cfg.animations) || {}).barSpeed || 350;

    const healthBar = $('bar-health');
    const armorWrap = $('armor-wrap');

    if (healthBar) {
        healthBar.style.width = data.health + '%';
        $('num-health').textContent = data.health;
        $('bar-health').parentElement.parentElement.classList.toggle('low', data.health <= 40);
    }

    const stamBar = $('bar-stamina');
    if (stamBar) {
        stamBar.style.width = data.stamina + '%';
        $('num-stamina').textContent = data.stamina;
    }

    if (armorWrap) {
        armorWrap.style.display = 'flex';
        $('bar-armor').style.width = data.armor + '%';
        $('num-armor').textContent = data.armor;
    }
}

function updatePlayers(data) {
    const playersTxt = $('players-txt');
    if (playersTxt) playersTxt.textContent = data.current + ' / ' + data.max;
}

function updateClock(data) {
    if ($('clock-time')) $('clock-time').textContent = data.time;
    if ($('clock-date')) $('clock-date').textContent = data.date;
}

function updateVehicle(data) {
    const panel = $('speedometer');
    if (!panel) return;

    if (data.visible) {
        panel.classList.add('visible');
        $('speedo-speed').textContent = data.speed;
        $('speedo-gear').textContent = data.gear;

        const max = state.cfg && state.cfg.speedoMax ? state.cfg.speedoMax : 200;
        const pct = Math.max(0, Math.min(100, (data.speed / max) * 100));
        const rings = panel.querySelector('.rings-active');
        if (rings) rings.style.setProperty('--speed-pct', pct);

        const arrowEl = $('speedo-arrow');
        if (arrowEl) {
            arrowEl.classList.remove('arrow-up', 'arrow-down', 'arrow-flat');
            if (data.arrow === 'up') {
                arrowEl.textContent = '\u25B2';
                arrowEl.classList.add('arrow-up');
            } else if (data.arrow === 'down') {
                arrowEl.textContent = '\u25BC';
                arrowEl.classList.add('arrow-down');
            } else {
                arrowEl.textContent = '\u2014';
                arrowEl.classList.add('arrow-flat');
            }
        }

        const beltWrap = $('belt-wrap');
        if (beltWrap) {
            beltWrap.classList.toggle('belt-on', !!data.belt);
            const beltIcon = $('belt-icon');
            if (beltIcon) beltIcon.src = data.belt ? 'icons/belt-on.svg' : 'icons/belt-off.svg';
        }
    } else {
        panel.classList.remove('visible');
    }
}

function updateVoice(data) {
    const icon = $('voice-icon');
    const status = icon && icon.parentElement;

    if (data.enabled !== true || (state.cfg && state.cfg.show && state.cfg.show.voice === false)) {
        if (status) setHide(status, true);
        return;
    }
    if (!icon) return;

    setHide(status, false);
    icon.classList.remove('talking', 'radio');

    if (data.radio) {
        icon.src = 'icons/radio.svg';
        icon.classList.add('radio');
    } else if (data.talking) {
        icon.src = 'icons/mic.svg';
        icon.classList.add('talking');
    } else {
        icon.src = 'icons/mic-off.svg';
    }
}

function setPaused(data) {
    state.paused = !!data.paused;
    updateVisibility();
}

function toggleVisibility(data) {
    state.toggleHidden = data.visible === false;
    updateVisibility();
}

function updateVisibility() {
    const root = $('hud-root');
    root.classList.toggle('hidden', state.toggleHidden || state.paused);
    root.classList.toggle('paused', state.paused);
}

function setEditMode(data) {
    applyEditMode(!!data.enabled);
}

function resetHud() {
    applyPositions();
}

/* ---------------- message bus ---------------- */

window.addEventListener('message', (event) => {
    const data = event.data || {};
    switch (data.action) {
        case 'setup': setup(data.data || {}); break;
        case 'updatePlayer': updatePlayer(data.data || {}); break;
        case 'updateJob': updateJob(data.data || {}); break;
        case 'updateMoney': updateMoney(data.data || {}); break;
        case 'updateStatus': updateStatus(data.data || {}); break;
        case 'updatePlayers': updatePlayers(data.data || {}); break;
        case 'updateClock': updateClock(data.data || {}); break;
        case 'updateVehicle': updateVehicle(data.data || {}); break;
        case 'updateVoice': updateVoice(data.data || {}); break;
        case 'setPaused': setPaused(data.data || {}); break;
        case 'toggleVisibility': toggleVisibility(data.data || {}); break;
        case 'setEditMode': setEditMode(data.data || {}); break;
        case 'resetHud': resetHud(); break;
        default: break;
    }
});

/* ---------------- listeners ---------------- */

document.addEventListener('pointerdown', onPointerDown);
document.addEventListener('pointermove', onPointerMove);
document.addEventListener('pointerup', onPointerUp);

/* ---------------- NUI bridge (ready + error reporting) ---------------- */

function postNUI(type, message) {
    try {
        fetch('https://' + GetParentResourceName(), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify({ type: type, message: message })
        }).catch(() => {});
    } catch (e) { /* ignore */ }
}

window.addEventListener('error', (e) => {
    postNUI('nuiError', (e && e.message) ? e.message : 'unknown error');
});

window.addEventListener('load', () => {
    postNUI('ready', null);
});